package com.studentportal.util;

import java.io.UnsupportedEncodingException;
import java.security.SecureRandom;

/**
 * BCrypt password hashing implementation in pure Java.
 * Compatible with PHP password_hash($pass, PASSWORD_BCRYPT) and password_verify().
 * Implementation based on Damien Miller's jBCrypt (OpenBSD-style Blowfish password hashing).
 */
public class BCrypt {
    // Table of expansion values
    private static final int[] BCRYPT_PALETTE = {
        0x242a2d32, 0x302a2d32, 0x342a2d32, 0x362a2d32,
        0x382a2d32, 0x3a2a2d32, 0x3c2a2d32, 0x3e2a2d32
    };

    private static final int BCRYPT_SALT_LEN = 16;
    private static final int BLOWFISH_NUM_ROUNDS = 16;

    // Standard base64 table for BCrypt
    private static final char[] BCRYPT_BASE64_CODE = {
        '.', '/', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
        'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
        'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h',
        'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
        'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5',
        '6', '7', '8', '9'
    };

    private static final byte[] BCRYPT_INDEX = {
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,  0,  1,
        54, 55, 56, 57, 58, 59, 60, 61, 62, 63, -1, -1, -1, -1, -1, -1,
        -1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16,
        17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, -1, -1, -1, -1, -1,
        -1, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42,
        43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, -1, -1, -1, -1, -1
    };

    private static final int[] P_ORIG = {
        0x243f6a88, 0x85a308d3, 0x13198a2e, 0x03707344,
        0xa4093822, 0x299f31d0, 0x082efa98, 0xec4e6c89,
        0x452821e6, 0x38d01377, 0xbe5466cf, 0x34e90c6c,
        0xc0ac29b7, 0xc97c50dd, 0x3f84d5b5, 0xb5470917,
        0x9216d5d9, 0x8979fb1b
    };

    private static final int[] S_ORIG = {
        0xd1310ba6, 0x98dfb5ac, 0x2ffd72db, 0xd01adfb7,
        0xb8e1afed, 0x6a267e96, 0xba7c9045, 0xf12c7f99,
        0x24a19947, 0xb3916cf7, 0x0801f2e2, 0x858efc16,
        0x636920d8, 0x71574e69, 0xa458fea3, 0xf4933d7e,
        0x0d95748f, 0x728eb658, 0x718bcd58, 0x82154aee,
        0x7b54a41d, 0xc25a59b5, 0x9c30d539, 0x2af26013,
        0xc5d1b023, 0x286085f0, 0xca417918, 0xb8db38ef,
        0x8e79dcb0, 0x603a180e, 0x6c9e0e8b, 0xb01e8a3e,
        0xd71577c1, 0xbd314b27, 0x78af2fda, 0x55605c60,
        0xe65525f3, 0xaa55ab94, 0x57489862, 0x63e81440,
        0x55ca396a, 0x2aab10b6, 0xb4cc5c34, 0x1141e8ce,
        0xa15486af, 0x7c72e993, 0xb3ee1411, 0x636fbc2a,
        0x2ba9c55d, 0x741831f6, 0xce5c3e16, 0x9b87931e,
        0xafd6ba33, 0x6c24cf5c, 0x7a325381, 0x28958677,
        0x3b8f4898, 0x6b4bb9af, 0xc4bfe81b, 0x66282193,
        0x61d809cc, 0xfb21a991, 0x487cac60, 0x5dec8032,
        0xef845d5d, 0xe98575b1, 0xdc262302, 0xeb651b88,
        0x23893e81, 0xd396acc5, 0x0f6d6ff3, 0x83f44239,
        0x2e0b4482, 0xa4842004, 0x69c8f04a, 0x9e1f9b5e,
        0x21c66842, 0xf6e96c9a, 0x670c9c61, 0xabd388f0,
        0x6a51a0d2, 0xd8542f68, 0x960fa728, 0xab5133a3,
        0x6eef0b6c, 0x137a3be4, 0xba3bf050, 0x7efb2bbe,
        0x9b1143a5, 0x8356cf19, 0xaca46e6b, 0x99bfb925,
        0x7a43ab76, 0x54d690a0, 0xb572cca5, 0x4ce41bbc,
        0x25237194, 0x14f07f45, 0x214e02a3, 0x869e1cd2,
        0x49a94242, 0xa27e96e0, 0x85663f73, 0x299f76b6,
        0xc21c4024, 0x62d32f4c, 0x5bfe025b, 0x52b667f2,
        0x4386b66e, 0x6367240a, 0x64a1430f, 0xc0162d4a,
        0x3ab60e47, 0x38cca833, 0x44ee7e28, 0xb972be3b,
        0x56a6427e, 0xb1b02324, 0x86b09a64, 0x7291f37e,
        0x2bf77f14, 0x600185e5, 0x45a1be9b, 0x75b76e0b,
        0x834728cb, 0x07f6eab9, 0xb8e34eed, 0xd69de22c,
        0xebbff670, 0x6a5e16ea, 0x14c72c07, 0xbce474fb,
        0x1a83f276, 0x62a91a91, 0x113f9c6d, 0xc172cd90,
        0x9a3e00b8, 0x879734e0, 0x8c49521a, 0x1d8f28dc,
        0x0da3f2d8, 0x33e6d160, 0x56019521, 0x83340c43,
        0xf6111456, 0x30e0a526, 0x23a053ff, 0x444d412f,
        0x9092c527, 0x46325b8a, 0x616d4726, 0x32832005,
        0x3b4c10e0, 0x397ff894, 0x13fbf63c, 0x992e5ac4,
        0x7f1c3d37, 0x6d030482, 0xfe12822a, 0x001db64b,
        0x0c01890d, 0x01b7a458, 0xb833ea77, 0x4e326550,
        0x95fb2974, 0x731bf7fa, 0x2188e960, 0x879415ac,
        0x24709f79, 0xae777f9f, 0x54961608, 0xec4515d9,
        0xe77e4eec, 0x35657722, 0x61dd45ce, 0x52632203,
        0x87311db6, 0x738d1524, 0xc24e008c, 0xbc0a16e0,
        0x160a664d, 0x2cdb9978, 0x35f420d0, 0x15728369,
        0xe37693e3, 0xfaac5594, 0x47291f45, 0x444d5386,
        0x0fc26a81, 0x223b1f67, 0x4e742614, 0x80860614,
        0xdebf624e, 0xd033d262, 0x321f3019, 0xb2b4e532,
        0x4a93adac, 0x55f0ab41, 0x73a45525, 0x53664361,
        0x52f36ff6, 0x8669e083, 0x850c9692, 0x72364666,
        0x8f7e9f1d, 0x87e99e47, 0x4e149a45, 0x6c5184a4,
        0x866e94fe, 0xcb292f60, 0xf67d2fb9, 0xd1e0e93d,
        0x6c4f696e, 0x6aab3180, 0x3099502b, 0x87121b24,
        0x4bf28ae1, 0xa51da453, 0x475b1062, 0x0c93ff9d,
        0xd4584235, 0x4da6eb5b, 0x0da629e0, 0x0f01da2f,
        0xae0a2361, 0xd0a284e6, 0xd1ff422f, 0x0c340fb5,
        0x50c30986, 0x93954f01, 0xa2f729e4, 0x49c47dec,
        0x3295d69f, 0xac6cdb36, 0x49e560f3, 0x8e8cf971,
        0xab909d54, 0x1dbd5119, 0x65933446, 0xd79f9459,
        0xda26e422, 0xb767230a, 0x90e37a0e, 0xec0e7660
    };

    private static final int[] BCRYPT_TEST_WORD = {
        0x4f727068, 0x65616e42, 0x65686f6c, 0x64657253, 0x63727970, 0x74202020
    };

    private int[] p;
    private int[] s;

    public BCrypt() {
        p = new int[P_ORIG.length];
        s = new int[S_ORIG.length];
    }

    private void initKey() {
        System.arraycopy(P_ORIG, 0, p, 0, P_ORIG.length);
        System.arraycopy(S_ORIG, 0, s, 0, S_ORIG.length);
    }

    private int encipher(int[] lr, int off) {
        int l = lr[off];
        int r = lr[off + 1];

        l ^= p[0];
        for (int i = 0; i <= 14; i += 2) {
            r ^= (((s[l >>> 24] + s[0x100 | ((l >>> 16) & 0xff)]) ^ s[0x200 | ((l >>> 8) & 0xff)]) + s[0x300 | (l & 0xff)]) ^ p[i + 1];
            l ^= (((s[r >>> 24] + s[0x100 | ((r >>> 16) & 0xff)]) ^ s[0x200 | ((r >>> 8) & 0xff)]) + s[0x300 | (r & 0xff)]) ^ p[i + 2];
        }
        r ^= p[16];
        l ^= p[17];

        lr[off] = r;
        lr[off + 1] = l;
        return 0;
    }

    private void eksBlowfishKey(byte[] data, byte[] key) {
        int keylen = key.length;
        int datalen = data.length;

        int j = 0;
        for (int i = 0; i < p.length; i++) {
            int d = 0;
            for (int k = 0; k < 4; k++) {
                d = (d << 8) | (key[j] & 0xff);
                j = (j + 1) % keylen;
            }
            p[i] ^= d;
        }

        int[] lr = new int[2];
        j = 0;
        for (int i = 0; i < p.length; i += 2) {
            lr[0] ^= (data[j % datalen] & 0xff) << 24 | (data[(j + 1) % datalen] & 0xff) << 16 | (data[(j + 2) % datalen] & 0xff) << 8 | (data[(j + 3) % datalen] & 0xff);
            lr[1] ^= (data[(j + 4) % datalen] & 0xff) << 24 | (data[(j + 5) % datalen] & 0xff) << 16 | (data[(j + 6) % datalen] & 0xff) << 8 | (data[(j + 7) % datalen] & 0xff);
            j = (j + 8) % datalen;
            encipher(lr, 0);
            p[i] = lr[0];
            p[i + 1] = lr[1];
        }

        for (int i = 0; i < s.length; i += 2) {
            lr[0] ^= (data[j % datalen] & 0xff) << 24 | (data[(j + 1) % datalen] & 0xff) << 16 | (data[(j + 2) % datalen] & 0xff) << 8 | (data[(j + 3) % datalen] & 0xff);
            lr[1] ^= (data[(j + 4) % datalen] & 0xff) << 24 | (data[(j + 5) % datalen] & 0xff) << 16 | (data[(j + 6) % datalen] & 0xff) << 8 | (data[(j + 7) % datalen] & 0xff);
            j = (j + 8) % datalen;
            encipher(lr, 0);
            s[i] = lr[0];
            s[i + 1] = lr[1];
        }
    }

    private byte[] cryptRaw(byte[] password, byte[] salt, int logRounds) {
        int rounds = 1 << logRounds;
        initKey();
        eksBlowfishKey(salt, password);

        for (int i = 0; i < rounds; i++) {
            eksBlowfishKey(new byte[salt.length], password);
            eksBlowfishKey(new byte[password.length], salt);
        }

        int[] cdata = (int[]) BCRYPT_TEST_WORD.clone();
        for (int i = 0; i < 64; i++) {
            for (int j = 0; j < cdata.length; j += 2) {
                encipher(cdata, j);
            }
        }

        byte[] ret = new byte[cdata.length * 4];
        for (int i = 0, j = 0; i < cdata.length; i++) {
            ret[j++] = (byte) ((cdata[i] >>> 24) & 0xff);
            ret[j++] = (byte) ((cdata[i] >>> 16) & 0xff);
            ret[j++] = (byte) ((cdata[i] >>> 8) & 0xff);
            ret[j++] = (byte) (cdata[i] & 0xff);
        }
        return ret;
    }

    private static byte char64(char x) {
        if ((int) x < 0 || (int) x > BCRYPT_INDEX.length) {
            return -1;
        }
        return BCRYPT_INDEX[(int) x];
    }

    private static void encodeBase64(byte[] d, int len, StringBuilder rs) {
        int off = 0;
        int c1, c2;

        while (off < len) {
            c1 = (d[off++] & 0xff);
            rs.append(BCRYPT_BASE64_CODE[(c1 >> 2) & 0x3f]);
            c1 = (c1 & 0x03) << 4;
            if (off >= len) {
                rs.append(BCRYPT_BASE64_CODE[c1 & 0x3f]);
                break;
            }
            c2 = (d[off++] & 0xff);
            c1 |= (c2 >> 4) & 0x0f;
            rs.append(BCRYPT_BASE64_CODE[c1 & 0x3f]);
            c1 = (c2 & 0x0f) << 2;
            if (off >= len) {
                rs.append(BCRYPT_BASE64_CODE[c1 & 0x3f]);
                break;
            }
            c2 = (d[off++] & 0xff);
            c1 |= (c2 >> 6) & 0x03;
            rs.append(BCRYPT_BASE64_CODE[c1 & 0x3f]);
            rs.append(BCRYPT_BASE64_CODE[c2 & 0x3f]);
        }
    }

    private static byte[] decodeBase64(String s, int maxlen) {
        int slen = s.length();
        int off = 0;
        byte[] rs = new byte[maxlen];
        int rslen = 0;

        while (off < slen - 1 && rslen < maxlen) {
            int c1 = char64(s.charAt(off++));
            int c2 = char64(s.charAt(off++));
            if (c1 == -1 || c2 == -1) break;
            rs[rslen++] = (byte) ((c1 << 2) | ((c2 & 0x30) >> 4));
            if (off >= slen || rslen >= maxlen) break;
            int c3 = char64(s.charAt(off++));
            if (c3 == -1) break;
            rs[rslen++] = (byte) (((c2 & 0x0f) << 4) | ((c3 & 0x3c) >> 2));
            if (off >= slen || rslen >= maxlen) break;
            int c4 = char64(s.charAt(off++));
            if (c4 == -1) break;
            rs[rslen++] = (byte) (((c3 & 0x03) << 6) | c4);
        }
        return rs;
    }

    public static String hashPassword(String password, int logRounds) {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[BCRYPT_SALT_LEN];
        random.nextBytes(salt);

        StringBuilder rs = new StringBuilder();
        rs.append("$2y$");
        if (logRounds < 10) rs.append("0");
        rs.append(logRounds);
        rs.append("$");
        encodeBase64(salt, salt.length, rs);

        return hashpw(password, rs.toString());
    }

    public static String hashpw(String password, String salt) {
        BCrypt b = new BCrypt();
        int off = 0;

        if (!salt.startsWith("$2a$") && !salt.startsWith("$2y$") && !salt.startsWith("$2b$")) {
            throw new IllegalArgumentException("Invalid salt version");
        }
        off = 4;
        if (salt.charAt(off + 2) > '$') {
            throw new IllegalArgumentException("Missing $ in salt rounds");
        }
        int rounds = Integer.parseInt(salt.substring(off, off + 2));
        String realSalt = salt.substring(off + 3, off + 25);

        byte[] saltb = decodeBase64(realSalt, BCRYPT_SALT_LEN);
        byte[] passwordb;
        try {
            byte[] pwBytes = password.getBytes("UTF-8");
            passwordb = new byte[pwBytes.length + 1];
            System.arraycopy(pwBytes, 0, passwordb, 0, pwBytes.length);
            passwordb[pwBytes.length] = 0;
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException("UTF-8 not supported", e);
        }

        byte[] hashed = b.cryptRaw(passwordb, saltb, rounds);

        StringBuilder res = new StringBuilder();
        res.append(salt.substring(0, off + 3));
        encodeBase64(saltb, saltb.length, res);
        encodeBase64(hashed, 23, res);
        return res.toString();
    }

    /**
     * Verifies a plain password against an OpenBSD/PHP BCrypt hash ($2y$ or $2a$).
     */
    public static boolean checkpw(String plaintext, String hashed) {
        if (plaintext == null || hashed == null || hashed.length() < 28) {
            return false;
        }
        try {
            String computed = hashpw(plaintext, hashed);
            return slowEquals(computed, hashed);
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean slowEquals(String a, String b) {
        if (a == null || b == null) return false;
        int diff = a.length() ^ b.length();
        for (int i = 0; i < a.length() && i < b.length(); i++) {
            diff |= a.charAt(i) ^ b.charAt(i);
        }
        return diff == 0;
    }
}
